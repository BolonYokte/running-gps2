import { cva, type VariantProps } from "class-variance-authority";
import { twMerge } from "tailwind-merge";
import { forwardRef } from "react";

const button = cva(
  "inline-flex items-center justify-center gap-2 font-semibold transition-all duration-200 select-none disabled:opacity-50 disabled:cursor-not-allowed",
  {
    variants: {
      intent: {
        primary: "bg-gradient-to-r from-indigo-500 to-blue-500 text-white shadow-md hover:shadow-lg hover:from-indigo-600 hover:to-blue-600 active:scale-95",
        secondary: "bg-neutral-100 text-neutral-900 hover:bg-neutral-200 border border-neutral-300 active:scale-95",
        ghost: "text-neutral-800 hover:bg-neutral-100 active:scale-95",
        danger: "bg-gradient-to-r from-red-500 to-red-600 text-white hover:from-red-600 hover:to-red-700 shadow-md hover:shadow-lg active:scale-95",
        success: "bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-md hover:shadow-lg hover:from-green-600 hover:to-emerald-600 active:scale-95",
        warning: "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md hover:shadow-lg hover:from-amber-600 hover:to-orange-600 active:scale-95",
      },
      size: {
        xs: "text-xs px-2 py-1 rounded-md",
        sm: "text-sm px-3 py-1.5 rounded-lg",
        md: "text-base px-4 py-2 rounded-xl",
        lg: "text-lg px-5 py-3 rounded-2xl",
        xl: "text-xl px-6 py-4 rounded-2xl",
      },
    },
    defaultVariants: { intent: "primary", size: "md" },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof button> {
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  loading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, intent, size, leftIcon, rightIcon, children, loading, disabled, ...props }, ref) => (
    <button
      ref={ref}
      className={twMerge(button({ intent, size }), className)}
      disabled={disabled || loading}
      {...props}
    >
      {loading ? (
        <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
      ) : (
        leftIcon
      )}
      {children}
      {!loading && rightIcon}
    </button>
  )
);

Button.displayName = "Button";