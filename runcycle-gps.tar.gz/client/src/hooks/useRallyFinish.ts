import { useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { metersToDeg, segsIntersect, signedDistanceToGate, haversineM } from '@/lib/geo';
import { projectOnPolylineM } from '@/lib/nav';

export function useRallyFinish() {
  const { activeTrack, trackView, rally, setRally, setNav, nav } = useAppStore();

  // 1) Construir puerta de meta (perpendicular al último tramo)
  useEffect(() => {
    if (!activeTrack?.geometry?.coordinates?.length) {
      setRally({ finishGate: null });
      return;
    }
    const coords = activeTrack.geometry.coordinates as [number,number][];
    const fwd = !trackView.reversed ? coords : [...coords].reverse();
    if (fwd.length < 2) return;

    const a = fwd[fwd.length-2]; // [lng,lat]
    const b = fwd[fwd.length-1]; // [lng,lat]
    const latB = b[1], lngB = b[0];

    // dirección del último tramo en metros
    const mPerDegLat = 111_320;
    const mPerDegLng = Math.cos(latB * Math.PI/180) * 111_320;
    const dLat_m = (b[1]-a[1]) * mPerDegLat;
    const dLng_m = (b[0]-a[0]) * mPerDegLng;
    const theta = Math.atan2(dLat_m, dLng_m);      // rumbo del tramo
    const normal = theta + Math.PI/2;              // perpendicular

    const half = 25; // semilongitud de la puerta (m) — puedes subir a 30–35 si hay jitter
    const dx_m = Math.cos(normal)*half;
    const dy_m = Math.sin(normal)*half;
    const [dLat, dLng] = metersToDeg(latB, dx_m, dy_m);

    const pa: [number,number] = [latB - dLat, lngB - dLng]; // [lat,lng]
    const pb: [number,number] = [latB + dLat, lngB + dLng];

    setRally({ finishGate: { a: pa, b: pb, center: [latB, lngB] } });
    console.log('[FinishGate] Puerta de meta construida:', { center: [latB, lngB], half });
  }, [activeTrack?.id, trackView.reversed]);

  // 2) Detección de cruce (solo en RUNNING)
  useEffect(() => {
    if (rally.phase !== 'running') return;
    if (!rally.finishGate) return;
    const f1 = rally.prevFix, f2 = rally.lastFix;
    if (!f1 || !f2) return;

    const p1: [number,number] = [f1.lat, f1.lng];
    const p2: [number,number] = [f2.lat, f2.lng];
    const { a, b, center } = rally.finishGate;

    // Intersección geométrica + cambio de lado + cercanía a puerta
    const crossed = segsIntersect(p1, p2, a, b);
    const s1 = signedDistanceToGate({lat:p1[0], lng:p1[1]}, rally.finishGate);
    const s2 = signedDistanceToGate({lat:p2[0], lng:p2[1]}, rally.finishGate);
    const sideFlip = (s1 <= 0 && s2 >= 0) || (s1 >= 0 && s2 <= 0);
    const d2 = haversineM({lat:p2[0], lng:p2[1]}, {lat:center[0], lng:center[1]});
    const nearGate = d2 <= 20; // tolerancia de proximidad

    console.debug('[FINISH-DETECT]', { crossed, sideFlip, d2, phase: rally.phase });

    let shouldFinish = crossed && sideFlip && nearGate;

    // Fallback: si la proyección sobre el track ya está a <10 m del final y estás cerca de la puerta
    if (!shouldFinish && activeTrack?.geometry?.coordinates) {
      const line = (!trackView.reversed ? activeTrack.geometry.coordinates
                                        : [...activeTrack.geometry.coordinates].reverse()) as [number,number][];
      const totalM = line.reduce((acc, _, i) => i ? acc + haversineM(
        {lat: line[i-1][1], lng: line[i-1][0]},
        {lat: line[i][1],   lng: line[i][0]}
      ) : 0, 0);
      const proj = projectOnPolylineM({lat:p2[0], lng:p2[1]}, line);
      if (nearGate && (totalM - proj.sM) <= 10) {
        console.debug('[FINISH-DETECT] fallback by projection near end');
        shouldFinish = true;
      }
    }

    if (shouldFinish) {
      const now = Date.now();
      if (!rally.lastFinishCrossAt || now - rally.lastFinishCrossAt > rally.crossDebounceMs) {
        setRally({ phase: 'finished', endTs: now, lastFinishCrossAt: now });
        // congelar navegación si quieres
        setNav({ enabled: false, nextDistM: 0, nextIndex: nav.steps.length - 1 });
        console.log('[FINISH] ¡Meta detectada! Tiempo total:', ((now - (rally.startTs || now)) / 1000).toFixed(1), 's');
      }
    }
  }, [rally.phase, rally.prevFix?.ts, rally.lastFix?.ts, rally.finishGate, activeTrack?.id, trackView.reversed]);
}