import { useEffect, useRef } from 'react';
import { useAppStore } from '@/lib/store';
import { GPSFixPipeline, type GPSFix } from '@/lib/gpsFilters';
import { projectOnPolylineM } from '@/lib/nav';

function hav(a:{lat:number,lng:number}, b:{lat:number,lng:number}) {
  const R=6371000, toRad=(d:number)=>d*Math.PI/180;
  const dLat=toRad(b.lat-a.lat), dLon=toRad(b.lng-a.lng);
  const s1=toRad(a.lat), s2=toRad(b.lat);
  const A=Math.sin(dLat/2)**2 + Math.cos(s1)*Math.cos(s2)*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(A));
}

export function useRallyGeofencing() {
  const { activeTrack, trackView, rally, setRally, setFix, geoCfg, simulationMode, appMode, setNav } = useAppStore();
  const pipelineRef = useRef<GPSFixPipeline | null>(null);
  const stableCountRef = useRef(0);

  // Inicializar pipeline GPS cuando cambie el track
  useEffect(() => {
    if (!activeTrack?.geometry?.coordinates?.length) {
      pipelineRef.current = null;
      return;
    }
    
    const line = !trackView.reversed 
      ? (activeTrack.geometry.coordinates as [number,number][])
      : [...(activeTrack.geometry.coordinates as [number,number][])].reverse();
      
    // Crear pipeline con función de proyección
    pipelineRef.current = new GPSFixPipeline((point: { lat: number; lng: number }) => {
      const { sM, distToLineM } = projectOnPolylineM(point, line);
      return { sM, xtrackM: distToLineM };
    });
    
    console.log('[GPS Pipeline] Inicializado para track:', activeTrack.name);
  }, [activeTrack?.id, trackView.reversed]);

  useEffect(() => {
    if (!activeTrack?.geometry?.coordinates?.length) return;
    
    // En modo simulación, no usar GPS real
    if (simulationMode) {
      console.log('[Rally] Modo simulación: no usar GPS real');
      return;
    }

    let watchId: number | null = null;
    const coords = activeTrack.geometry.coordinates as [number,number][];
    const fwd = !trackView.reversed ? coords : [...coords].reverse();
    const start = { lng: fwd[0][0], lat: fwd[0][1] };

    function onPos(pos: GeolocationPosition) {
      const { latitude:lat, longitude:lng, accuracy:acc=99, speed } = pos.coords;
      const ts = pos.timestamp;
      
      // Warm-up básico
      const accOK = acc <= 50; // Usar gate más estricto en pipeline
      stableCountRef.current = accOK ? Math.min(stableCountRef.current + 1, 3) : 0;
      if (stableCountRef.current < 2) {
        console.log(`[Rally] GPS warm-up: ${stableCountRef.current}/3 fixes estables`);
        return;
      }

      // Usar el nuevo pipeline GPS mejorado
      if (!pipelineRef.current) return;
      
      const rawFix: GPSFix = { lat, lng, acc, ts };
      
      // Determinar velocidad máxima según el modo de app
      const profileMaxKph = appMode === 'running' ? 25 : 65; // Running: 25 km/h, Otros: 65 km/h
      
      const processedState = pipelineRef.current.process(rawFix, profileMaxKph);
      if (!processedState) return; // Fix rechazado por el pipeline
      
      // Usar coordenadas procesadas (filtradas y potencialmente proyectadas al track)
      const finalLat = processedState.offtrack ? processedState.lat : processedState.lat;
      const finalLng = processedState.offtrack ? processedState.lng : processedState.lng;
      
      // Reportar fix procesado al store
      setFix({ 
        lat: finalLat, 
        lng: finalLng, 
        accuracy: acc, 
        speedMps: processedState.speedKph / 3.6, 
        ts 
      });
      
      // Actualizar heading de navegación con el heading calculado por el pipeline
      setNav({ headingDeg: processedState.headingDeg });

      // Geofencing con las coordenadas procesadas
      const dist = hav({ lat: finalLat, lng: finalLng }, start);
      setRally((old) => {
        const inside = dist <= (old.phase === 'armed' || old.phase === 'ready' ? geoCfg.exitRadiusM : geoCfg.enterRadiusM);
        const next: any = {
          distanceToStartM: Math.round(dist),
          canArm: inside,
        };
        
        // Transiciones de estado
        if (old.phase === 'idle') {
          next.phase = inside ? 'ready' : 'idle';
        } else if (old.phase === 'ready') {
          next.phase = inside ? 'armed' : 'idle';
        } else if (old.phase === 'armed') {
          if (!inside) next.phase = 'idle';
        }
        
        console.log(`[Rally] GPS mejorado: ${dist.toFixed(1)}m del inicio, velocidad: ${processedState.speedKph.toFixed(1)}km/h, offtrack: ${processedState.offtrack}, fase: ${old.phase} → ${next.phase || old.phase}`);
        
        return next;
      });
    }

    function onErr(e: GeolocationPositionError) { 
      console.warn('[Rally] GPS error:', e.code, e.message); 
    }

    try {
      console.log('[Rally] Iniciando geolocalización mejorada con pipeline One Euro...');
      watchId = navigator.geolocation.watchPosition(onPos, onErr, {
        enableHighAccuracy: true, // fuerza chip GPS en móviles
        maximumAge: 500,          // cache mínimo para estabilidad
        timeout: 10000            // timeout más generoso
      });
    } catch (e) { 
      console.warn('[Rally] Geolocalización no soportada', e); 
    }

    return () => { 
      if (watchId!=null) navigator.geolocation.clearWatch(watchId); 
    };
  }, [activeTrack?.id, trackView.reversed, geoCfg.enterRadiusM, geoCfg.exitRadiusM, geoCfg.minAccuracyM, geoCfg.smoothAlpha, simulationMode]);

  // Procesar GPS simulado cuando está en modo simulación
  useEffect(() => {
    if (!simulationMode || !activeTrack?.geometry?.coordinates?.length) return;
    if (!rally.lastFix) return;

    const coords = activeTrack.geometry.coordinates as [number,number][];
    const fwd = !trackView.reversed ? coords : [...coords].reverse();
    const start = { lng: fwd[0][0], lat: fwd[0][1] };
    
    const fix = rally.lastFix;
    const dist = hav({ lat: fix.lat, lng: fix.lng }, start);
    
    setRally((old) => {
      const inside = dist <= (old.phase === 'armed' || old.phase === 'ready' ? geoCfg.exitRadiusM : geoCfg.enterRadiusM);
      const next: any = {
        distanceToStartM: Math.round(dist),
        canArm: inside,
      };
      
      // Transiciones de estado
      if (old.phase === 'idle') {
        next.phase = inside ? 'ready' : 'idle';
      } else if (old.phase === 'ready') {
        next.phase = inside ? 'armed' : 'idle';
      } else if (old.phase === 'armed') {
        if (!inside) next.phase = 'idle';
      }
      
      console.log(`[Rally] SIM GPS: ${dist.toFixed(1)}m del inicio, dentro: ${inside}, fase: ${old.phase} → ${next.phase || old.phase}`);
      
      return next;
    });
    
  }, [simulationMode, rally.lastFix?.ts, activeTrack?.id, trackView.reversed, geoCfg.enterRadiusM, geoCfg.exitRadiusM]);
}