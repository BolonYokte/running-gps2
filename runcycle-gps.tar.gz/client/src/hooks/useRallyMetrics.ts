import { useEffect, useRef } from 'react';
import { useAppStore } from '@/lib/store';
import type { RallySplit, RallyLive } from '@/lib/store';
import * as turf from '@turf/turf';

export function useRallyMetrics() {
  const { rally, activeTrack, setRally } = useAppStore();
  const intervalRef = useRef<NodeJS.Timeout>();
  const speedHistoryRef = useRef<number[]>([]);

  // Cronómetro en vivo
  useEffect(() => {
    if (rally.phase === 'running' && rally.startTs) {
      intervalRef.current = setInterval(() => {
        const now = Date.now();
        const elapsedMs = now - rally.startTs!;
        
        setRally((prev: any) => ({
          ...prev,
          live: {
            ...prev.live,
            elapsedMs
          }
        }));
      }, 100); // Actualizar cada 100ms para suavidad
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = undefined;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [rally.phase, rally.startTs, setRally]);

  // Actualizar métricas en base al GPS
  useEffect(() => {
    if (!rally.lastFix || !activeTrack) return;

    const fix = rally.lastFix;
    const speedKmh = (fix.speedMps || 0) * 3.6;
    
    // Calcular distancia recorrida proyectando sobre el track
    let distanceM = 0;
    if (activeTrack.geometry) {
      try {
        const trackLine = turf.lineString(activeTrack.geometry.coordinates);
        const userPoint = turf.point([fix.lng, fix.lat]);
        const snapped = turf.nearestPointOnLine(trackLine, userPoint);
        distanceM = turf.length(turf.lineSlice(
          turf.point(activeTrack.geometry.coordinates[0]),
          snapped.geometry,
          trackLine
        ), { units: 'meters' });
      } catch (e) {
        console.warn('[RallyMetrics] Error calculando distancia:', e);
      }
    }

    // Mantener historial de velocidad para media móvil
    speedHistoryRef.current.push(speedKmh);
    if (speedHistoryRef.current.length > 10) {
      speedHistoryRef.current.shift();
    }
    
    const avgKmh = speedHistoryRef.current.reduce((a, b) => a + b, 0) / speedHistoryRef.current.length;
    const maxKmh = Math.max(rally.live?.maxKmh || 0, speedKmh);

    // Detectar splits cuando pasas por waypoints
    if (rally.phase === 'running' && rally.startTs) {
      const currentTimeMs = Date.now() - rally.startTs;
      
      // Chequear si pasamos el siguiente split
      if (distanceM >= rally.nextSplitSM && rally.nextSplitSM > 0) {
        const newSplit = {
          idx: rally.splits.length,
          sM: rally.nextSplitSM,
          timeMs: currentTimeMs,
          deltaMs: rally.splits.length > 0 ? 
            currentTimeMs - rally.splits[rally.splits.length - 1].timeMs : 
            currentTimeMs
        };

        console.log('[RallyMetrics] Split detectado:', newSplit);
        
        setRally((prev: any) => ({
          ...prev,
          splits: [...prev.splits, newSplit],
          nextSplitSM: prev.nextSplitSM + prev.splitEveryM,
          live: {
            ...prev.live,
            distanceM,
            avgKmh: Math.round(avgKmh * 10) / 10,
            maxKmh: Math.round(maxKmh * 10) / 10,
            lastSpeedMps: fix.speedMps || 0
          }
        }));
      } else {
        // Solo actualizar métricas sin splits
        setRally((prev: any) => ({
          ...prev,
          live: {
            ...prev.live,
            distanceM,
            avgKmh: Math.round(avgKmh * 10) / 10,
            maxKmh: Math.round(maxKmh * 10) / 10,
            lastSpeedMps: fix.speedMps || 0
          }
        }));
      }
    }
  }, [rally.lastFix, activeTrack, rally.phase, rally.startTs, rally.nextSplitSM, rally.splits, rally.live?.maxKmh, setRally]);

  // Funciones de utilidad
  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const formatDistance = (meters: number) => {
    if (meters < 1000) return `${Math.round(meters)}m`;
    return `${(meters / 1000).toFixed(1)}km`;
  };

  return {
    metrics: rally.live || { elapsedMs: 0, distanceM: 0, avgKmh: 0, maxKmh: 0, lastSpeedMps: 0 },
    splits: rally.splits || [],
    phase: rally.phase,
    formatTime,
    formatDistance,
    currentSplit: (rally.splits?.length || 0) + 1,
    nextSplitDistance: rally.nextSplitSM || 500
  };
}