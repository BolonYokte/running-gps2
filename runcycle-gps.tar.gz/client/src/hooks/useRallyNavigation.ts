import { useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { buildStepsFromLine, projectOnPolylineM, bearingDeg, haversineM } from '@/lib/nav';

export function useRallyNavigation() {
  const { activeTrack, trackView, rally, nav, setNav, geoCfg } = useAppStore();

  // Al pasar a RUNNING -> construir pasos y habilitar navegación
  useEffect(() => {
    if (rally.phase !== 'running') return;
    if (!activeTrack?.geometry?.coordinates?.length) return;

    const base = !trackView.reversed
      ? (activeTrack.geometry.coordinates as [number,number][])
      : [...(activeTrack.geometry.coordinates as [number,number][])].reverse();

    const steps = buildStepsFromLine(base);
    console.log('[Nav] Iniciando navegación con', steps.length, 'pasos');
    setNav({ enabled: true, steps, nextIndex: Math.min(1, steps.length-1) }); // próximo paso tras "start"
  }, [rally.phase, activeTrack?.id, trackView.reversed]);

  // En cada fix, actualiza progreso, heading, distancia al siguiente paso, offroute
  useEffect(() => {
    if (!nav.enabled) return;
    if (!rally.lastFix || !activeTrack?.geometry?.coordinates?.length) return;

    const line = !trackView.reversed
      ? (activeTrack.geometry.coordinates as [number,number][])
      : [...(activeTrack.geometry.coordinates as [number,number][])].reverse();

    // Proyección a la línea
    const { sM, point, distToLineM } = projectOnPolylineM(rally.lastFix, line);
    
    // Snap al track cuando estás cerca (< 50m) para mejor precisión visual
    const onRail = distToLineM <= 50;
    const displayPoint = onRail ? point : rally.lastFix;

    // Usar heading del pipeline GPS (derivado de velocidad) si disponible
    let heading = nav.headingDeg;
    
    // Si tenemos velocidad > 1.8 km/h, usar heading del GPS
    const currentSpeed = rally.lastFix?.speedMps ? rally.lastFix.speedMps * 3.6 : 0;
    if (currentSpeed > 1.8) {
      // El pipeline GPS ya calcula heading robusto desde velocidad
      heading = nav.headingDeg;
    } else {
      // Si parados, calcular heading hacia adelante en el track (lookahead)
      const lookAhead = sM + geoCfg.lookAheadM;
      let acc = 0, bIdx = 1;
      for (; bIdx < line.length; bIdx++) {
        const A = { lng: line[bIdx-1][0], lat: line[bIdx-1][1] };
        const B = { lng: line[bIdx][0], lat: line[bIdx][1] };
        const seg = haversineM(A, B);
        if (acc + seg >= lookAhead) {
          const t = Math.max(0, Math.min(1, (lookAhead - acc) / seg));
          const pL: [number, number] = [A.lng + (B.lng - A.lng) * t, A.lat + (B.lat - A.lat) * t];
          heading = bearingDeg([point.lng, point.lat], pL);
          break;
        }
        acc += seg;
      }
      if (bIdx >= line.length) {
        const last = line[line.length-1];
        heading = bearingDeg([point.lng, point.lat], last);
      }
    }

    // Siguiente paso pendiente
    let i = nav.nextIndex;
    const steps = nav.steps;
    while (i < steps.length && steps[i].sM <= sM + 5) i++; // considera alcanzado si estás a <5m
    const bounded = Math.min(i, steps.length - 1);
    const next = steps[bounded];
    const nextDist = Math.max(0, next.sM - sM);

    setNav({
      headingDeg: heading,
      currS_M: sM,
      nextIndex: bounded,
      nextDistM: Math.round(nextDist),
      offRoute: distToLineM > nav.offRouteThresholdM,
      // Guardamos el punto proyectado para que el mapa lo use
      displayPointLat: displayPoint.lat,
      displayPointLng: displayPoint.lng,
      onRail: onRail
    });

    console.log(`[Nav] Progreso: ${sM.toFixed(0)}m, siguiente: ${next?.text} en ${nextDist.toFixed(0)}m, fuera: ${distToLineM > nav.offRouteThresholdM}`);
  }, [rally.lastFix?.ts, nav.enabled, trackView.reversed, activeTrack?.id]);
}