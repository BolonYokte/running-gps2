import { useEffect } from 'react';
import { useAppStore } from '@/lib/store';
import { haversineM, segsIntersect, signedDistanceToGate } from '@/lib/nav';

export function useRallyStart() {
  const { activeTrack, trackView, rally, setRally, showToast } = useAppStore();

  // Construir puerta de salida
  useEffect(() => {
    if (!activeTrack?.geometry?.coordinates?.length) return;
    const coords = activeTrack.geometry.coordinates as [number,number][];
    const fwd = !trackView.reversed ? coords : [...coords].reverse();
    if (fwd.length < 2) return;
    
    const a = fwd[0]; // primer punto (salida)
    const b = fwd[1]; // segundo punto
    
    // Calcular rumbo y puerta perpendicular
    const toRad = (d: number) => d * Math.PI / 180;
    const toDeg = (r: number) => r * 180 / Math.PI;
    
    const [lon1, lat1] = [a[0], a[1]].map(toRad);
    const [lon2, lat2] = [b[0], b[1]].map(toRad);
    const y = Math.sin(lon2 - lon1) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(lon2 - lon1);
    const brng = (toDeg(Math.atan2(y, x)) + 360) % 360;
    const normal = (brng + 90) % 360;

    // Construir puerta ±15m perpendicular centrada en punto de salida
    const mPerDegLat = 111320;
    const mPerDegLng = Math.cos(a[1] * Math.PI / 180) * 111320;
    const half = 15; // metros
    const dLat = (Math.cos(normal * Math.PI / 180) * half) / mPerDegLat;
    const dLng = (Math.sin(normal * Math.PI / 180) * half) / mPerDegLng;

    const pa: [number, number] = [a[1] - dLat, a[0] - dLng]; // [lat, lng]
    const pb: [number, number] = [a[1] + dLat, a[0] + dLng]; // [lat, lng]

    setRally({ startGate: { a: pa, b: pb } });
  }, [activeTrack?.id, trackView.reversed]);

  // Detectar cruce de puerta en ARMED - VERSIÓN SIMPLIFICADA
  useEffect(() => {
    if (rally.phase !== 'armed') return;
    if (!rally.lastFix) return;
    if (!activeTrack?.geometry?.coordinates?.length) return;
    
    const coords = activeTrack.geometry.coordinates as [number,number][];
    const fwd = !trackView.reversed ? coords : [...coords].reverse();
    const startPoint = fwd[0]; // [lng, lat]
    
    // Calcular distancia al punto de inicio del track
    const startPos = { lat: startPoint[1], lng: startPoint[0] };
    const currentPos = rally.lastFix;
    const distToStart = haversineM(currentPos, startPos);
    
    console.log('[Rally] Checking start trigger:', { 
      phase: rally.phase,
      distToStart: distToStart.toFixed(1),
      threshold: '12m'
    });
    
    // Si está cerca del inicio (< 12m) y se mueve hacia adelante en el track
    if (distToStart < 12) {
      // Debounce para evitar doble disparo
      const now = Date.now();
      if (now - (rally.lastStartCrossAt || 0) < rally.crossDebounceMs) {
        console.log('[Rally] Debounced - too soon since last crossing');
        return;
      }

      // Verificar que se está moviendo hacia adelante en el track
      if (rally.prevFix) {
        const prevDistToStart = haversineM(rally.prevFix, startPos);
        const movingAway = distToStart > prevDistToStart;
        
        console.log('[Rally] Movement check:', {
          prevDist: prevDistToStart.toFixed(1),
          currDist: distToStart.toFixed(1),
          movingAway
        });
        
        if (!movingAway) return; // Todavía acercándose al inicio
      }

      console.log('[Rally] ¡Autoarranque! Iniciando rally por proximidad al inicio...');
      showToast('🏁 Rally iniciado automáticamente!', 'success');
      setRally({ 
        phase: 'running',
        startTs: now,
        lastStartCrossAt: now
      });
    }

  }, [rally.phase, rally.prevFix?.ts, rally.lastFix?.ts, activeTrack?.id, trackView.reversed]);
}