import { useEffect, useRef } from 'react';

export function useWakeLock(enabled: boolean) {
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);

  useEffect(() => {
    // Check if Wake Lock API is supported
    if (!('wakeLock' in navigator)) {
      console.warn('[WakeLock] Wake Lock API not supported in this browser');
      return;
    }

    const requestWakeLock = async () => {
      try {
        if (enabled && !wakeLockRef.current) {
          wakeLockRef.current = await navigator.wakeLock.request('screen');
          console.log('[WakeLock] Screen wake lock activated');
          
          // Listen for wake lock release
          wakeLockRef.current.addEventListener('release', () => {
            console.log('[WakeLock] Screen wake lock released');
            wakeLockRef.current = null;
          });
        }
      } catch (err) {
        console.error('[WakeLock] Failed to request wake lock:', err);
        wakeLockRef.current = null;
      }
    };

    const releaseWakeLock = async () => {
      if (wakeLockRef.current) {
        try {
          await wakeLockRef.current.release();
          wakeLockRef.current = null;
          console.log('[WakeLock] Screen wake lock manually released');
        } catch (err) {
          console.error('[WakeLock] Failed to release wake lock:', err);
        }
      }
    };

    if (enabled) {
      requestWakeLock();
    } else {
      releaseWakeLock();
    }

    // Handle visibility change - reacquire wake lock when page becomes visible
    const handleVisibilityChange = () => {
      if (enabled && document.visibilityState === 'visible' && !wakeLockRef.current) {
        requestWakeLock();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Cleanup function
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      releaseWakeLock();
    };
  }, [enabled]);

  return {
    isSupported: 'wakeLock' in navigator,
    isActive: wakeLockRef.current !== null
  };
}