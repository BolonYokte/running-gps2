import { useEffect, useState, useRef } from "react";

interface WebSocketState {
  lastMessage: string | null;
  isConnected: boolean;
  error: string | null;
}

export function useWebSocket() {
  const [state, setState] = useState<WebSocketState>({
    lastMessage: null,
    isConnected: false,
    error: null,
  });
  
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const connect = () => {
      try {
        const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
        const wsUrl = `${protocol}//${window.location.host}/ws`;
        
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          console.log("WebSocket connected");
          setState(prev => ({
            ...prev,
            isConnected: true,
            error: null,
          }));
        };

        ws.onmessage = (event) => {
          setState(prev => ({
            ...prev,
            lastMessage: event.data,
          }));
        };

        ws.onclose = (event) => {
          console.log("WebSocket disconnected:", event.code, event.reason);
          setState(prev => ({
            ...prev,
            isConnected: false,
          }));

          // Attempt to reconnect after 3 seconds
          if (!event.wasClean) {
            reconnectTimeoutRef.current = setTimeout(connect, 3000);
          }
        };

        ws.onerror = (error) => {
          console.error("WebSocket error:", error);
          setState(prev => ({
            ...prev,
            error: "WebSocket connection failed",
            isConnected: false,
          }));
        };
      } catch (error) {
        console.error("Failed to create WebSocket:", error);
        setState(prev => ({
          ...prev,
          error: "Failed to create WebSocket connection",
          isConnected: false,
        }));
      }
    };

    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      
      if (wsRef.current) {
        wsRef.current.close(1000, "Component unmounting");
      }
    };
  }, []);

  const sendMessage = (message: string) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(message);
    }
  };

  return {
    ...state,
    sendMessage,
  };
}
