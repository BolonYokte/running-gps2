// Utilidades geométricas para detección de puertas de rally
// Todas las funciones usan [lat,lng] (Leaflet-style) para evitar confusiones.

// Intersección robusta de segmentos (lat,lng)
export function segsIntersect(p1:[number,number], p2:[number,number], q1:[number,number], q2:[number,number]) {
  function orient(a:[number,number], b:[number,number], c:[number,number]) {
    const ax=a[1], ay=a[0], bx=b[1], by=b[0], cx=c[1], cy=c[0]; // x=lng, y=lat
    const v = (bx-ax)*(cy-by) - (by-ay)*(cx-bx);
    if (Math.abs(v) < 1e-12) return 0;
    return v > 0 ? 1 : -1;
  }
  function onSeg(a:[number,number], b:[number,number], c:[number,number]) {
    const min = (x:number,y:number)=>Math.min(x,y);
    const max = (x:number,y:number)=>Math.max(x,y);
    const ax=a[1], ay=a[0], bx=b[1], by=b[0], cx=c[1], cy=c[0];
    return cx >= min(ax,bx)-1e-12 && cx <= max(ax,bx)+1e-12 &&
           cy >= min(ay,by)-1e-12 && cy <= max(ay,by)+1e-12;
  }
  const o1=orient(p1,p2,q1), o2=orient(p1,p2,q2), o3=orient(q1,q2,p1), o4=orient(q1,q2,p2);
  if (o1!==o2 && o3!==o4) return true;
  // Colinealidades
  if (o1===0 && onSeg(p1,p2,q1)) return true;
  if (o2===0 && onSeg(p1,p2,q2)) return true;
  if (o3===0 && onSeg(q1,q2,p1)) return true;
  if (o4===0 && onSeg(q1,q2,p2)) return true;
  return false;
}

// Distancia geodésica aproximada (m)
export function haversineM(a:{lat:number,lng:number}, b:{lat:number,lng:number}) {
  const R=6371000, toRad=(d:number)=>d*Math.PI/180;
  const dLat=toRad(b.lat-a.lat), dLon=toRad(b.lng-a.lng);
  const s1=toRad(a.lat), s2=toRad(b.lat);
  const A=Math.sin(dLat/2)**2 + Math.cos(s1)*Math.cos(s2)*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(A));
}

// Metros → grados en lat/lng a una latitud dada
export function metersToDeg(lat:number, dx:number, dy:number): [number, number] {
  const mPerDegLat = 111_320;
  const mPerDegLng = Math.cos(lat * Math.PI/180) * 111_320;
  return [dy / mPerDegLat, dx / mPerDegLng]; // [dLat, dLng]
}

// Signo (lado) respecto a la puerta (lat,lng)
export function signedDistanceToGate(p:{lat:number,lng:number}, gate:{a:[number,number],b:[number,number]}) {
  const ax=gate.a[0], ay=gate.a[1];
  const bx=gate.b[0], by=gate.b[1];
  const px=p.lat, py=p.lng;
  const ABx = bx-ax, ABy = by-ay;
  const APx = px-ax, APy = py-ay;
  const cross = ABx*APy - ABy*APx; // signo del lado
  return cross;
}