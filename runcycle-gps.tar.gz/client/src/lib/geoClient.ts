// Distancia Haversine en metros
export function haversineM(a: { lat: number, lng: number }, b: { lat: number, lng: number }) {
  const R = 6371000, toRad = (d: number) => d * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat), dLon = toRad(b.lng - a.lng);
  const s1 = toRad(a.lat), s2 = toRad(b.lat);
  const A = Math.sin(dLat / 2) ** 2 + Math.cos(s1) * Math.cos(s2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(A));
}

/** Devuelve coordenada [lat,lng] a una distancia acumulada sM sobre la polilínea */
export function interpolateAtS(line: [number, number][], sM: number): [number, number] {
  if (!line || line.length < 2) throw new Error('line vacía');
  if (sM <= 0) return [line[0][1], line[0][0]];
  let acc = 0;
  for (let i = 1; i < line.length; i++) {
    const A = { lat: line[i - 1][1], lng: line[i - 1][0] };
    const B = { lat: line[i][1], lng: line[i][0] };
    const d = haversineM(A, B);
    if (acc + d >= sM) {
      const t = (sM - acc) / d; // 0..1
      const lat = A.lat + (B.lat - A.lat) * t;
      const lng = A.lng + (B.lng - A.lng) * t;
      return [lat, lng];
    }
    acc += d;
  }
  // si sM supera el total, devolver el final
  return [line[line.length - 1][1], line[line.length - 1][0]];
}

/** Genera puntos [lat,lng] para cada waypoint sM dado */
export function waypointsLatLng(line: [number, number][], waypointsSm: number[]) {
  return waypointsSm.map((sM, i) => {
    const [lat, lng] = interpolateAtS(line, sM);
    // Para distancias menores a 1000m, mostrar en metros; sino en km
    const displayValue = sM < 1000 ? Math.round(sM) : Math.round(sM / 1000);
    const displayUnit = sM < 1000 ? 'm' : 'km';
    const km = Math.round(sM / 1000);
    return { lat, lng, sM, km, displayValue, displayUnit, idx: i };
  });
}

/** Genera waypoints con spacing especificado para una geometría dada */
export function buildWaypoints(geometry: any, spacingM: number = 1000) {
  const line = geometry.coordinates as [number, number][];
  if (!line || line.length < 2) return [];
  
  // Calcular distancia total
  let total = 0;
  for (let i = 1; i < line.length; i++) {
    total += haversineM(
      { lat: line[i - 1][1], lng: line[i - 1][0] }, 
      { lat: line[i][1], lng: line[i][0] }
    );
  }
  
  // Generar waypoints cada spacingM metros
  const sm: number[] = [];
  for (let s = spacingM; s < total; s += spacingM) {
    sm.push(s);
  }
  
  return waypointsLatLng(line, sm);
}

/** Genera waypoints cada 1km para una geometría dada (backward compatibility) */
export function build1kmWaypoints(geometry: any) {
  return buildWaypoints(geometry, 1000);
}