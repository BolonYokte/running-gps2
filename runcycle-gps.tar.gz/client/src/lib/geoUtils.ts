import * as turf from "@turf/turf";

export interface Position {
  lat: number;
  lng: number;
  accuracy?: number;
  timestamp: number;
}

export interface ProjectedPosition {
  lat: number;
  lng: number;
  distanceAlongTrack: number;
  distanceFromTrack: number;
  bearingToTrack: number;
}

/**
 * Project a position onto a track polyline and calculate progress
 */
export function projectToPolyline(
  position: Position,
  trackCoordinates: number[][],
): ProjectedPosition {
  const point = turf.point([position.lng, position.lat]);
  const line = turf.lineString(trackCoordinates);
  
  const nearest = turf.nearestPointOnLine(line, point);
  const distanceFromTrack = turf.distance(point, nearest, { units: "meters" });
  
  // Calculate distance along track
  const lineSlice = turf.lineSlice(
    turf.point(trackCoordinates[0]),
    nearest,
    line
  );
  const distanceAlongTrack = turf.length(lineSlice, { units: "meters" });
  
  // Calculate bearing from position to nearest point on track
  const bearingToTrack = turf.bearing(point, nearest);
  
  return {
    lat: nearest.geometry.coordinates[1],
    lng: nearest.geometry.coordinates[0],
    distanceAlongTrack,
    distanceFromTrack,
    bearingToTrack,
  };
}

/**
 * Check if user has crossed a threshold (start/finish detection)
 */
export function checkThresholdCrossing(
  currentDistance: number,
  previousDistance: number,
  threshold: number,
  tolerance: number = 20,
): "forward" | "backward" | null {
  const crossedForward = 
    previousDistance < threshold - tolerance && 
    currentDistance >= threshold - tolerance;
    
  const crossedBackward = 
    previousDistance > threshold + tolerance && 
    currentDistance <= threshold + tolerance;
  
  if (crossedForward) return "forward";
  if (crossedBackward) return "backward";
  return null;
}

/**
 * Calculate speed with smoothing using median filter
 */
export function smoothSpeed(
  positions: Position[],
  windowSize: number = 5,
): number {
  if (positions.length < 2) return 0;
  
  // Filter out positions with poor accuracy
  const goodPositions = positions.filter(pos => 
    !pos.accuracy || pos.accuracy <= 50
  );
  
  if (goodPositions.length < 2) return 0;
  
  // Calculate instantaneous speeds
  const speeds: number[] = [];
  
  for (let i = 1; i < goodPositions.length; i++) {
    const prev = goodPositions[i - 1];
    const curr = goodPositions[i];
    
    const distance = turf.distance(
      turf.point([prev.lng, prev.lat]),
      turf.point([curr.lng, curr.lat]),
      { units: "meters" }
    );
    
    const timeDelta = (curr.timestamp - prev.timestamp) / 1000; // seconds
    
    if (timeDelta > 0) {
      const speedMs = distance / timeDelta;
      const speedKmh = speedMs * 3.6;
      speeds.push(speedKmh);
    }
  }
  
  if (speeds.length === 0) return 0;
  
  // Apply median filter
  const recentSpeeds = speeds.slice(-windowSize);
  const sorted = [...recentSpeeds].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  
  return median;
}

/**
 * Calculate distance between two points
 */
export function calculateDistance(
  point1: [number, number],
  point2: [number, number],
): number {
  return turf.distance(
    turf.point([point1[1], point1[0]]), // [lng, lat]
    turf.point([point2[1], point2[0]]), // [lng, lat]
    { units: "meters" }
  );
}

/**
 * Calculate bearing between two points
 */
export function calculateBearing(
  point1: [number, number],
  point2: [number, number],
): number {
  return turf.bearing(
    turf.point([point1[1], point1[0]]), // [lng, lat]
    turf.point([point2[1], point2[0]]) // [lng, lat]
  );
}

/**
 * Check if point is within bounding box
 */
export function isPointInBbox(
  point: [number, number],
  bbox: [number, number, number, number],
): boolean {
  const [lat, lng] = point;
  const [minLat, minLng, maxLat, maxLng] = bbox;
  
  return lat >= minLat && lat <= maxLat && lng >= minLng && lng <= maxLng;
}
