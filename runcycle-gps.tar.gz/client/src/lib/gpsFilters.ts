// Filtro One Euro para suavizado adaptativo de GPS
export class OneEuroFilter {
  private prevV = 0;
  private prevX = 0;
  private prevT = 0;
  private initialized = false;

  constructor(
    private minCut = 1.0,
    private beta = 0.01
  ) {}

  private alpha(cut: number, dt: number) {
    const tau = 1 / (2 * Math.PI * cut);
    return 1 / (1 + tau / dt);
  }

  update(x: number, t: number): number {
    if (!this.initialized) {
      this.initialized = true;
      this.prevX = x;
      this.prevT = t;
      return x;
    }

    const dt = Math.max(0.02, (t - this.prevT) / 1000);
    const dx = (x - this.prevX) / dt;
    const cutDx = this.minCut;
    const aDx = this.alpha(cutDx, dt);
    const v = aDx * dx + (1 - aDx) * this.prevV;
    const cutX = this.minCut + this.beta * Math.abs(v);
    const aX = this.alpha(cutX, dt);
    const xf = aX * x + (1 - aX) * this.prevX;

    this.prevV = v;
    this.prevX = xf;
    this.prevT = t;
    return xf;
  }

  reset() {
    this.initialized = false;
    this.prevV = 0;
    this.prevX = 0;
    this.prevT = 0;
  }
}

// Tipos para el pipeline de GPS
export type GPSFix = {
  lat: number;
  lng: number;
  acc: number;
  ts: number;
};

export type GPSState = {
  lat: number;
  lng: number;
  vLat: number;
  vLng: number;
  sM: number;
  offtrack: boolean;
  speedKph: number;
  headingDeg: number;
};

// Función de distancia Haversine
function haversineM(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371000;
  const toRad = (d: number) => d * Math.PI / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lng - a.lng);
  const s1 = toRad(a.lat);
  const s2 = toRad(b.lat);
  const A = Math.sin(dLat / 2) ** 2 + Math.cos(s1) * Math.cos(s2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(A));
}

// Pipeline de procesamiento GPS con filtros y map-matching
export class GPSFixPipeline {
  private fLat = new OneEuroFilter(1.0, 0.02);
  private fLng = new OneEuroFilter(1.0, 0.02);
  private fSpeed = new OneEuroFilter(0.5, 0.1);
  private last?: GPSState & { ts: number };

  constructor(
    private projectOnTrack: (p: { lat: number; lng: number }) => { sM: number; xtrackM: number }
  ) {}

  process(raw: GPSFix, profileMaxKph = 65): GPSState | null {
    console.log('[GPS Pipeline] Processing fix:', { lat: raw.lat, lng: raw.lng, acc: raw.acc });

    // 1) Gate de calidad - descartar fixes malos
    if (!Number.isFinite(raw.lat) || !Number.isFinite(raw.lng)) {
      console.log('[GPS Pipeline] Fix rejected: invalid coordinates');
      return null;
    }

    if (raw.acc && raw.acc > 50) {
      console.log('[GPS Pipeline] Fix rejected: accuracy too low:', raw.acc);
      return null;
    }

    // Verificar saltos imposibles
    if (this.last) {
      const dM = haversineM(this.last, raw);
      const dt = Math.max(0.2, (raw.ts - this.last.ts) / 1000);
      const kph = (dM / dt) * 3.6;
      
      if (kph > profileMaxKph * 1.4) {
        console.log('[GPS Pipeline] Fix rejected: impossible speed:', kph, 'km/h');
        return null;
      }
    }

    // 2) Suavizado con One Euro Filter
    const lat = this.fLat.update(raw.lat, raw.ts);
    const lng = this.fLng.update(raw.lng, raw.ts);

    // 3) Proyección al track y map-matching
    const proj = this.projectOnTrack({ lat, lng });
    let sM = proj.sM;
    const off = proj.xtrackM > 30; // Corredor de 30m

    // 4) S monótono - evita pasos atrás por jitter GPS
    if (this.last && !off) {
      sM = Math.max(this.last.sM - 8, sM); // Permite pequeños retrocesos (8m)
    } else if (this.last && off) {
      sM = this.last.sM; // Si off-track, no avances sobre el track
    }

    // 5) Calcular velocidad y heading
    const dt = this.last ? Math.max(0.2, (raw.ts - this.last.ts) / 1000) : 0.2;
    const vLat = this.last ? (lat - this.last.lat) / dt : 0;
    const vLng = this.last ? (lng - this.last.lng) / dt : 0;

    // Velocidad en km/h suavizada
    const speedMs = this.last ? haversineM(this.last, { lat, lng }) / dt : 0;
    const speedKph = this.fSpeed.update(speedMs * 3.6, raw.ts);

    // Heading derivado de la velocidad (más robusto que brújula)
    let headingDeg = 0;
    if (speedKph > 1.8) { // Solo calcular heading si nos movemos > 0.5 m/s
      headingDeg = (Math.atan2(vLng, vLat) * 180 / Math.PI + 360) % 360;
    } else if (this.last) {
      headingDeg = this.last.headingDeg; // Congelar heading si parados
    }

    const state: GPSState & { ts: number } = {
      lat,
      lng,
      vLat,
      vLng,
      sM,
      offtrack: off,
      speedKph,
      headingDeg,
      ts: raw.ts
    };

    console.log('[GPS Pipeline] Processed state:', {
      sM: Math.round(state.sM),
      speedKph: Math.round(state.speedKph * 10) / 10,
      headingDeg: Math.round(state.headingDeg),
      offtrack: state.offtrack,
      xtrackM: Math.round(proj.xtrackM)
    });

    this.last = state;
    return state;
  }

  reset() {
    this.fLat.reset();
    this.fLng.reset();
    this.fSpeed.reset();
    this.last = undefined;
    console.log('[GPS Pipeline] Reset filters');
  }
}