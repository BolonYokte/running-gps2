// Sistema de internacionalización global
import { create } from 'zustand';

export type Language = 'es' | 'en';

interface LanguageStore {
  language: Language;
  setLanguage: (lang: Language) => void;
}

export const useLanguageStore = create<LanguageStore>((set) => ({
  language: 'es',
  setLanguage: (lang) => {
    set({ language: lang });
    // Guardar en localStorage para persistencia
    localStorage.setItem('rallyo-language', lang);
  },
}));

// Inicializar idioma desde localStorage
const savedLanguage = localStorage.getItem('rallyo-language') as Language;
if (savedLanguage && (savedLanguage === 'es' || savedLanguage === 'en')) {
  useLanguageStore.getState().setLanguage(savedLanguage);
}

export const translations = {
  es: {
    // Splash screen
    selectMode: 'Selecciona tu modo',
    subtitle: 'Tracks • Rally • Offroad',
    comingSoon: 'PRÓXIMAMENTE',
    modes: {
      'moto-extrem': 'MOTO EXTREM',
      'moto-offroad': 'MOTO OFFROAD', 
      'running': 'RUNNING',
      'moto-onroad': 'MOTO ONROAD',
      'mtb-cycling-offroad': 'MTB CYCLING OFFROAD',
      'cycling': 'CYCLING'
    },
    // Menú principal
    menu: {
      createTrack: 'Crear track',
      loadTrack: 'Cargar track',
      searchNearby: 'Buscar tracks cercanos',
      leaderboards: 'Leaderboards',
      changeMode: 'Cambiar modo',
      settings: 'Ajustes'
    },
    // Rally y navegación
    rally: {
      readyToStart: 'Listo para salir',
      running: 'CORRIENDO',
      finished: 'FINALIZADO',
      elapsed: 'Tiempo',
      distance: 'Distancia',
      speed: 'Velocidad',
      avgSpeed: 'Vel. media',
      maxSpeed: 'Vel. máx',
      invertTrack: 'Invertir track'
    },
    // Tracks
    tracks: {
      nearby: 'Tracks cercanos',
      distance: 'Distancia',
      start: 'Inicio',
      waypoints: 'Waypoints cada',
      delete: 'Eliminar',
      activate: 'Activar',
      options: 'Opciones del track',
      hideOptions: 'Ocultar opciones'
    },
    // Rally arm panel
    rallyArm: {
      armStart: 'Armar salida',
      distanceToStart: 'Distancia a la salida',
      readyToGo: 'Listo para salir',
      armed: 'Armado',
      cancel: 'Cancelar',
      getCloser: 'Acércate al punto de inicio para activar',
      pressReady: 'Pulsa "Listo para salir" para armar el rally',
      crossLine: '¡Cruza la línea de salida para autoarranque!'
    },
    // Rally HUD
    hud: {
      time: 'TIEMPO',
      distance: 'DISTANCIA', 
      avgSpeed: 'MEDIA',
      maxSpeed: 'PUNTA',
      segment: 'SEGMENTO',
      completed: 'COMPLETADOS'
    },
    // Screen wake lock
    wakeLock: {
      activated: 'Pantalla bloqueada - no se apagará',
      deactivated: 'Bloqueo de pantalla desactivado',
      notSupported: 'Bloqueo de pantalla no soportado en este navegador'
    },
    // Formularios y botones
    common: {
      save: 'Guardar',
      cancel: 'Cancelar',
      close: 'Cerrar',
      confirm: 'Confirmar',
      loading: 'Cargando...',
      error: 'Error',
      success: 'Éxito'
    }
  },
  en: {
    // Splash screen
    selectMode: 'Select your mode',
    subtitle: 'Tracks • Rally • Offroad',
    comingSoon: 'COMING SOON',
    modes: {
      'moto-extrem': 'MOTO EXTREME',
      'moto-offroad': 'MOTO OFFROAD',
      'running': 'RUNNING', 
      'moto-onroad': 'MOTO ONROAD',
      'mtb-cycling-offroad': 'MTB CYCLING OFFROAD',
      'cycling': 'CYCLING'
    },
    // Menú principal
    menu: {
      createTrack: 'Create track',
      loadTrack: 'Load track',
      searchNearby: 'Search nearby tracks',
      leaderboards: 'Leaderboards',
      changeMode: 'Change mode',
      settings: 'Settings'
    },
    // Rally y navegación
    rally: {
      readyToStart: 'Ready to start',
      running: 'RUNNING',
      finished: 'FINISHED',
      elapsed: 'Time',
      distance: 'Distance',
      speed: 'Speed',
      avgSpeed: 'Avg speed',
      maxSpeed: 'Max speed',
      invertTrack: 'Invert track'
    },
    // Tracks
    tracks: {
      nearby: 'Nearby tracks',
      distance: 'Distance',
      start: 'Start',
      waypoints: 'Waypoints every',
      delete: 'Delete',
      activate: 'Activate',
      options: 'Track options',
      hideOptions: 'Hide options'
    },
    // Rally arm panel
    rallyArm: {
      armStart: 'Arm start',
      distanceToStart: 'Distance to start',
      readyToGo: 'Ready to go',
      armed: 'Armed',
      cancel: 'Cancel',
      getCloser: 'Get closer to start point to activate',
      pressReady: 'Press "Ready to go" to arm the rally',
      crossLine: 'Cross the start line for auto-start!'
    },
    // Rally HUD
    hud: {
      time: 'TIME',
      distance: 'DISTANCE',
      avgSpeed: 'AVERAGE', 
      maxSpeed: 'MAX',
      segment: 'SEGMENT',
      completed: 'COMPLETED'
    },
    // Screen wake lock
    wakeLock: {
      activated: 'Screen locked - will not turn off',
      deactivated: 'Screen lock deactivated',
      notSupported: 'Screen lock not supported in this browser'
    },
    // Formularios y botones
    common: {
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
      confirm: 'Confirm',
      loading: 'Loading...',
      error: 'Error',
      success: 'Success'
    }
  }
};

// Hook para usar traducciones
export function useTranslations() {
  const language = useLanguageStore((state) => state.language);
  return translations[language];
}