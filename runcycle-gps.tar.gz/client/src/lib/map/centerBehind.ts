// src/lib/map/centerBehind.ts
import L from "leaflet";

export function centerBehind(
  map: L.Map,
  latlng: L.LatLngExpression,
  fracFromBottom = 0.32               // 32% desde el borde inferior (subido 10%)
) {
  // 1) Asegura tamaño correcto
  map.invalidateSize(false);

  // 2) Calcula offset en píxeles (positivo hacia ARRIBA)
  const size = map.getSize();
  const offset = L.point(0, size.y * fracFromBottom);

  // 3) Proyecta y resta offset
  const projected = map.project(latlng as any).subtract(offset);
  const dest = map.unproject(projected);

  // 4) Pan
  map.panTo(dest, { animate: true });
}