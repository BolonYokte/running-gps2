// Distancia geodésica sencilla en metros
export function haversineM(a:{lat:number,lng:number}, b:{lat:number,lng:number}) {
  const R=6371000, toRad=(d:number)=>d*Math.PI/180;
  const dLat=toRad(b.lat-a.lat), dLon=toRad(b.lng-a.lng);
  const sLat1=toRad(a.lat), sLat2=toRad(b.lat);
  const A=Math.sin(dLat/2)**2 + Math.cos(sLat1)*Math.cos(sLat2)*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(A));
}

// Proyección del punto sobre la polilínea; devuelve s (m) y el punto proyectado
export function projectOnPolylineM(pt:{lat:number,lng:number}, line:[number,number][]) {
  let bestS=0, bestDist=Infinity, bestPoint:{lat:number,lng:number} | null = null;
  let acc=0;
  for (let i=1;i<line.length;i++){
    const A={lng:line[i-1][0], lat:line[i-1][1]};
    const B={lng:line[i][0],   lat:line[i][1]};
    // aproximación: subdivide en N=10
    let bestLocal = {d:Infinity, t:0, P:{lat:A.lat,lng:A.lng}};
    for (let t=0;t<=10;t++){
      const u=t/10;
      const P={lat:A.lat+(B.lat-A.lat)*u, lng:A.lng+(B.lng-A.lng)*u};
      const d=haversineM(pt,P);
      if (d<bestLocal.d){ bestLocal={d,t:u,P}; }
    }
    const segLen=haversineM(A,B);
    const sHere = acc + segLen*bestLocal.t;
    if (bestLocal.d < bestDist) {
      bestDist = bestLocal.d; bestS = sHere; bestPoint = bestLocal.P;
    }
    acc += segLen;
  }
  return { sM: bestS, point: bestPoint!, distToLineM: bestDist };
}

// Rumbo (°) aproximado entre dos [lng,lat]
export function bearingDeg(a:[number,number], b:[number,number]) {
  const toRad=(d:number)=>d*Math.PI/180, toDeg=(r:number)=>r*180/Math.PI;
  const [lon1,lat1]=[a[0],a[1]].map(toRad), [lon2,lat2]=[b[0],b[1]].map(toRad);
  const y=Math.sin(lon2-lon1)*Math.cos(lat2);
  const x=Math.cos(lat1)*Math.sin(lat2)-Math.sin(lat1)*Math.cos(lat2)*Math.cos(lon2-lon1);
  return (toDeg(Math.atan2(y,x))+360)%360;
}

// Construye "pasos" básicos (start/left/right/continue/finish) desde una LineString
export function buildStepsFromLine(line:[number,number][]) {
  const steps: { idx:number; lng:number; lat:number; type:'start'|'continue'|'left'|'right'|'finish'; text:string; sM:number }[] = [];
  if (line.length<2) return steps;
  // Distancia acumulada
  const S:number[]=[0];
  for (let i=1;i<line.length;i++){
    const A={lng:line[i-1][0],lat:line[i-1][1]}, B={lng:line[i][0],lat:line[i][1]};
    S.push(S[i-1]+haversineM(A,B));
  }
  // Paso inicial
  steps.push({ idx:0, lng:line[0][0], lat:line[0][1], type:'start', text:'Empieza', sM:0 });

  for (let i=1;i<line.length-1;i++){
    const a=line[i-1], b=line[i], c=line[i+1];
    const brAB=bearingDeg(a,b), brBC=bearingDeg(b,c);
    let diff = ((brBC - brAB + 540) % 360) - 180; // [-180,180]
    const abs = Math.abs(diff);
    if (abs < 25) continue; // casi recto -> sin paso
    const type = diff > 0 ? 'right' : 'left';
    const text = type==='right' ? 'Gira a la derecha' : 'Gira a la izquierda';
    steps.push({ idx:i, lng:b[0], lat:b[1], type, text, sM:S[i] });
  }

  // Paso final
  const last = line[line.length-1];
  steps.push({ idx:line.length-1, lng:last[0], lat:last[1], type:'finish', text:'Llegada', sM:S[S.length-1] });
  return steps;
}

// Detecta si dos segmentos se intersectan
export function segsIntersect(
  p1: [number, number], 
  p2: [number, number], 
  p3: [number, number], 
  p4: [number, number]
): boolean {
  const [x1, y1] = p1;
  const [x2, y2] = p2;
  const [x3, y3] = p3;
  const [x4, y4] = p4;

  const denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
  if (Math.abs(denom) < 1e-10) return false; // parallel

  const t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom;
  const u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom;

  return t >= 0 && t <= 1 && u >= 0 && u <= 1;
}

// Calcula la distancia firmada de un punto a una puerta (línea)
// Resultado positivo/negativo indica el lado de la puerta
export function signedDistanceToGate(p:{lat:number,lng:number}, gate:{a:[number,number], b:[number,number]}) {
  // puerta en lat,lng
  const [ax,ay] = [gate.a[1], gate.a[0]]; // lat, lng
  const [bx,by] = [gate.b[1], gate.b[0]]; // lat, lng
  const [px,py] = [p.lat, p.lng];
  
  // vector AB y AP en (lat,lng)
  const ABx = bx-ax, ABy = by-ay;
  const APx = px-ax, APy = py-ay;
  
  // producto cruz simple (aprox) → signo indica lado
  const cross = ABx*APy - ABy*APx;
  return cross; // signo: negativo/positivo según lado de la puerta
}