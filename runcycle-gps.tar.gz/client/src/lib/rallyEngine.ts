import { lineString, point, nearestPointOnLine, distance, along, lineSlice, length } from '@turf/turf';

export type GpsPoint = {
  lat: number;
  lng: number;
  accuracy?: number;
  speed?: number; // m/s
  timestamp: number;
};

export type TrackGeometry = {
  type: 'LineString';
  coordinates: [number, number][];
};

export type RallyState = {
  state: 'IDLE' | 'ARMED' | 'RUNNING' | 'FINISHED';
  progress: number; // 0-1
  distanceFromStart: number; // meters
  remainingKm: number;
  currentSpeed: number; // km/h
  projectedPosition?: GpsPoint;
  nearestWaypoint?: number;
  splitTimes: number[];
  startTime?: number;
};

export class RallyEngine {
  private track?: TrackGeometry;
  private trackLine?: any;
  private trackLength: number = 0;
  private waypoints: GpsPoint[] = [];
  private state: RallyState = {
    state: 'IDLE',
    progress: 0,
    distanceFromStart: 0,
    remainingKm: 0,
    currentSpeed: 0,
    splitTimes: []
  };
  
  private readonly PROXIMITY_THRESHOLD = 20; // meters
  private readonly SPEED_SMOOTHING_WINDOW = 5;
  private speedHistory: number[] = [];

  setTrack(track: TrackGeometry, waypointEveryM: number = 500) {
    this.track = track;
    this.trackLine = lineString(track.coordinates);
    this.trackLength = length(this.trackLine, { units: 'meters' });
    
    // Generate waypoints along the track
    this.waypoints = [];
    const numWaypoints = Math.floor(this.trackLength / waypointEveryM);
    
    for (let i = 0; i <= numWaypoints; i++) {
      const dist = i * waypointEveryM;
      const alongPoint = along(this.trackLine, dist, { units: 'meters' });
      this.waypoints.push({
        lat: alongPoint.geometry.coordinates[1],
        lng: alongPoint.geometry.coordinates[0],
        timestamp: 0
      });
    }

    this.state = { ...this.state, state: 'ARMED' };
  }

  updatePosition(gpsPoint: GpsPoint): RallyState {
    if (!this.trackLine) return this.state;

    const userPoint = point([gpsPoint.lng, gpsPoint.lat]);
    
    // Project user position onto track
    const snapped = nearestPointOnLine(this.trackLine, userPoint);
    const distanceFromStart = length(
      lineSlice(
        point(this.track!.coordinates[0]),
        snapped,
        this.trackLine
      ),
      { units: 'meters' }
    );

    // Update speed with smoothing
    if (gpsPoint.speed !== undefined) {
      this.speedHistory.push(gpsPoint.speed * 3.6); // convert m/s to km/h
      if (this.speedHistory.length > this.SPEED_SMOOTHING_WINDOW) {
        this.speedHistory.shift();
      }
      
      // Use median for smoothing
      const sortedSpeeds = [...this.speedHistory].sort((a, b) => a - b);
      const medianSpeed = sortedSpeeds[Math.floor(sortedSpeeds.length / 2)];
      this.state.currentSpeed = medianSpeed;
    }

    // Check rally state transitions
    if (this.state.state === 'ARMED') {
      const startPoint = point(this.track!.coordinates[0]);
      const distanceToStart = distance(userPoint, startPoint, { units: 'meters' });
      
      if (distanceToStart < this.PROXIMITY_THRESHOLD && this.state.currentSpeed > 2) {
        this.state.state = 'RUNNING';
        this.state.startTime = gpsPoint.timestamp;
      }
    }

    if (this.state.state === 'RUNNING') {
      const endPoint = point(this.track!.coordinates[this.track!.coordinates.length - 1]);
      const distanceToEnd = distance(userPoint, endPoint, { units: 'meters' });
      
      if (distanceToEnd < this.PROXIMITY_THRESHOLD) {
        this.state.state = 'FINISHED';
      }

      // Update progress
      this.state.progress = Math.min(distanceFromStart / this.trackLength, 1);
      this.state.distanceFromStart = distanceFromStart;
      this.state.remainingKm = Math.max(0, (this.trackLength - distanceFromStart) / 1000);

      // Check for waypoint splits
      this.checkWaypointSplits(userPoint, gpsPoint.timestamp);
    }

    // Update projected position
    this.state.projectedPosition = {
      lat: snapped.geometry.coordinates[1],
      lng: snapped.geometry.coordinates[0],
      timestamp: gpsPoint.timestamp
    };

    return { ...this.state };
  }

  private checkWaypointSplits(userPoint: any, timestamp: number) {
    if (!this.state.startTime) return;

    for (let i = this.state.splitTimes.length; i < this.waypoints.length; i++) {
      const waypoint = this.waypoints[i];
      const waypointPoint = point([waypoint.lng, waypoint.lat]);
      const dist = distance(userPoint, waypointPoint, { units: 'meters' });

      if (dist < this.PROXIMITY_THRESHOLD) {
        const splitTime = timestamp - this.state.startTime;
        this.state.splitTimes.push(splitTime);
        this.state.nearestWaypoint = i;
        break;
      }
    }
  }

  getState(): RallyState {
    return { ...this.state };
  }

  reset() {
    this.state = {
      state: 'IDLE',
      progress: 0,
      distanceFromStart: 0,
      remainingKm: 0,
      currentSpeed: 0,
      splitTimes: []
    };
    this.speedHistory = [];
  }

  armRally() {
    if (this.track) {
      this.state.state = 'ARMED';
    }
  }

  static formatTime(ms: number): string {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    return `${hours.toString().padStart(2, '0')}:${(minutes % 60).toString().padStart(2, '0')}:${(seconds % 60).toString().padStart(2, '0')}`;
  }

  static formatDistance(meters: number): string {
    if (meters < 1000) {
      return `${Math.round(meters)}m`;
    }
    return `${(meters / 1000).toFixed(1)}km`;
  }
}