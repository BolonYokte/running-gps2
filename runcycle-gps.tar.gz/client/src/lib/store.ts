import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';

export interface Track {
  id: string;
  name: string;
  description?: string;
  geojson: any;
  distanceM?: number;
  elevationGain?: number;
  difficulty?: 'easy' | 'moderate' | 'hard' | 'extreme';
  appMode: 'running' | 'cycling';
  waypointEveryM?: number;
  onroadKm?: number;
  offroadKm?: number;
  estimatedTimeMin?: number;
  surfaceData?: any;
  createdAt?: string;
  updatedAt?: string;
}

export interface Waypoint {
  id: string;
  trackId: string;
  waypointNumber: number;
  distanceFromStartM: number;
  lat: number;
  lng: number;
  elevation?: number;
}

export interface Attempt {
  id: string;
  trackId: string;
  userId?: string;
  displayName?: string;
  startTime: string;
  endTime?: string;
  totalTimeMs?: number;
  maxSpeedKmh?: number;
  avgSpeedKmh?: number;
  distanceCoveredM?: number;
  status: 'running' | 'finished' | 'abandoned';
  appMode: 'running' | 'cycling';
  score?: number;
  percentile?: number;
}

export interface Split {
  id: string;
  attemptId: string;
  waypointId: string;
  waypointNumber: number;
  timeFromStartMs: number;
  distanceFromStartM: number;
  speedKmh?: number;
}

export interface RallyState {
  phase: 'idle' | 'armed' | 'running' | 'finished';
  startTime: Date | null;
  endTime: Date | null;
  currentAttempt: Attempt | null;
}

export interface GPSState {
  position: {
    lat: number;
    lng: number;
    accuracy: number;
    speed?: number;
    heading?: number;
  } | null;
  isTracking: boolean;
  lastUpdate: Date | null;
}

export interface NearbyState {
  enabled: boolean;
  tracks: Track[];
  loading: boolean;
  selected: Track | null;
}

export interface UIState {
  activePanel: string | null;
  loading: boolean;
  toast: {
    message: string;
    type: 'success' | 'error' | 'info';
    visible: boolean;
  } | null;
}

interface AppStore {
  // Data
  tracks: Track[];
  waypoints: Waypoint[];
  attempts: Attempt[];
  splits: Split[];
  
  // Active selections
  activeTrack: Track | null;
  currentMode: 'running' | 'cycling';
  
  // States
  rallyState: RallyState;
  gpsState: GPSState;
  nearby: NearbyState;
  ui: UIState;
  
  // Actions
  setTracks: (tracks: Track[]) => void;
  setActiveTrack: (track: Track | null) => void;
  setCurrentMode: (mode: 'running' | 'cycling') => void;
  setRallyState: (state: Partial<RallyState>) => void;
  setGPSState: (state: Partial<GPSState>) => void;
  setNearby: (state: Partial<NearbyState>) => void;
  setUI: (state: Partial<UIState>) => void;
  
  // Computed
  getCurrentModeWaypointSpacing: () => number;
  getActiveTrackWaypoints: () => Waypoint[];
  getCurrentAttemptSplits: () => Split[];
}

export const useAppStore = create<AppStore>()(
  subscribeWithSelector((set, get) => ({
    // Initial data
    tracks: [],
    waypoints: [],
    attempts: [],
    splits: [],
    
    // Initial selections
    activeTrack: null,
    currentMode: 'running',
    
    // Initial states
    rallyState: {
      phase: 'idle',
      startTime: null,
      endTime: null,
      currentAttempt: null,
    },
    
    gpsState: {
      position: null,
      isTracking: false,
      lastUpdate: null,
    },
    
    nearby: {
      enabled: false,
      tracks: [],
      loading: false,
      selected: null,
    },
    
    ui: {
      activePanel: null,
      loading: false,
      toast: null,
    },
    
    // Actions
    setTracks: (tracks) => set({ tracks }),
    
    setActiveTrack: (track) => set({ activeTrack: track }),
    
    setCurrentMode: (mode) => set({ currentMode: mode }),
    
    setRallyState: (newState) => 
      set((state) => ({
        rallyState: { ...state.rallyState, ...newState }
      })),
    
    setGPSState: (newState) =>
      set((state) => ({
        gpsState: { ...state.gpsState, ...newState }
      })),
    
    setNearby: (newState) =>
      set((state) => ({
        nearby: { ...state.nearby, ...newState }
      })),
    
    setUI: (newState) =>
      set((state) => ({
        ui: { ...state.ui, ...newState }
      })),
    
    // Computed getters
    getCurrentModeWaypointSpacing: () => {
      const mode = get().currentMode;
      return mode === 'running' ? 100 : 1000; // 100m for running, 1000m for cycling
    },
    
    getActiveTrackWaypoints: () => {
      const { activeTrack, waypoints } = get();
      if (!activeTrack) return [];
      return waypoints.filter(w => w.trackId === activeTrack.id);
    },
    
    getCurrentAttemptSplits: () => {
      const { rallyState, splits } = get();
      if (!rallyState.currentAttempt) return [];
      return splits.filter(s => s.attemptId === rallyState.currentAttempt!.id);
    },
  }))
);

// Subscribe to mode changes to update waypoint spacing
useAppStore.subscribe(
  (state) => state.currentMode,
  (currentMode) => {
    console.log(`[Store] Mode changed to: ${currentMode}`);
    // You can add mode-specific logic here
  }
);

// Subscribe to rally state changes
useAppStore.subscribe(
  (state) => state.rallyState.phase,
  (phase) => {
    console.log(`[Store] Rally phase changed to: ${phase}`);
    // You can add phase-specific logic here
  }
);