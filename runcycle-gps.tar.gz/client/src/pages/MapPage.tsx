import { useEffect, useRef, useState, useCallback } from 'react';
import L, { Map as LeafletMap } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-rotate';
import 'leaflet-rotatedmarker';

// Expose Leaflet globally 
(window as any).L = L;

import { useAppStore } from '@/lib/store';
import { centerBehind } from '@/lib/map/centerBehind';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/Button';
import { Route, Menu, Navigation, Satellite, Search, Target, Play, Pause } from 'lucide-react';

// Fix for default markers
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Create custom track icon for nearby tracks
const createTrackIcon = (distance: number) => {
  const color = distance < 10000 ? '#ff4444' : distance < 50000 ? '#ff8800' : '#4444ff';
  const size = distance < 5000 ? 40 : distance < 20000 ? 35 : 30;
  
  return L.divIcon({
    html: `
      <div class="relative w-${size/4} h-${size/4} rounded-full ${color === '#ff4444' ? 'bg-red-500' : color === '#ff8800' ? 'bg-orange-500' : 'bg-blue-500'} 
                 shadow-lg flex items-center justify-center pulse-soft">
        <div class="text-white text-xs font-bold">${(distance/1000).toFixed(0)}km</div>
      </div>
    `,
    className: 'track-marker',
    iconSize: [size, size],
    iconAnchor: [size/2, size/2]
  });
};

export default function MapPage() {
  const mapRef = useRef<LeafletMap | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const trackLayerRef = useRef<L.LayerGroup | null>(null);
  const nearbyMarkersRef = useRef<L.LayerGroup | null>(null);
  
  const [satelliteMode, setSatelliteMode] = useState(false);
  const [canRecenter, setCanRecenter] = useState(false);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [currentMode, setCurrentMode] = useState<'running' | 'cycling'>('running');
  
  const { toast } = useToast();
  const { 
    tracks, 
    setTracks, 
    activeTrack, 
    setActiveTrack,
    rallyState,
    setRallyState,
    nearby,
    setNearby 
  } = useAppStore();

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    toast({
      title: type === 'error' ? 'Error' : type === 'success' ? 'Éxito' : 'Info',
      description: message,
      variant: type === 'error' ? 'destructive' : 'default',
      duration: 3000,
    });
  }, [toast]);

  // Initialize map
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      center: [43.3750, -8.4083], // A Coruña, Spain
      zoom: 13,
      zoomControl: false,
      attributionControl: false,
      rotate: true,
      bearing: 0,
      touchRotate: true,
      rotateControl: {
        closeOnZeroBearing: false
      },
      shiftKeyRotate: true,
    });

    // Add zoom controls in custom position
    L.control.zoom({ position: 'topright' }).addTo(map);

    // Add tile layers
    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    });

    const satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
      attribution: '© Esri'
    });

    osm.addTo(map);

    // Create layer groups
    trackLayerRef.current = L.layerGroup().addTo(map);
    nearbyMarkersRef.current = L.layerGroup().addTo(map);

    mapRef.current = map;

    // Switch tile layers
    const switchLayers = (useSatellite: boolean) => {
      if (useSatellite) {
        map.removeLayer(osm);
        map.addLayer(satellite);
      } else {
        map.removeLayer(satellite);
        map.addLayer(osm);
      }
    };

    // Listen for satellite mode changes
    const handleSatelliteChange = () => switchLayers(satelliteMode);
    return () => {
      map.remove();
    };
  }, []);

  // Update satellite mode
  useEffect(() => {
    if (!mapRef.current) return;
    
    const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
    const satellite = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}');
    
    mapRef.current.eachLayer(layer => {
      if (layer instanceof L.TileLayer) {
        mapRef.current!.removeLayer(layer);
      }
    });
    
    if (satelliteMode) {
      satellite.addTo(mapRef.current);
    } else {
      osm.addTo(mapRef.current);
    }
  }, [satelliteMode]);

  // GPS tracking
  useEffect(() => {
    if (!navigator.geolocation) {
      showToast('Geolocalización no disponible', 'error');
      return;
    }

    let watchId: number;

    const success = (position: GeolocationPosition) => {
      const { latitude, longitude, accuracy } = position.coords;
      
      if (accuracy > 100) return; // Skip inaccurate readings
      
      setUserLocation({ lat: latitude, lng: longitude });
      setCanRecenter(true);

      if (!mapRef.current) return;

      // Update or create user marker
      if (userMarkerRef.current) {
        userMarkerRef.current.setLatLng([latitude, longitude]);
      } else {
        const userIcon = L.divIcon({
          html: '<div class="w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg"></div>',
          className: 'user-marker',
          iconSize: [16, 16],
          iconAnchor: [8, 8]
        });
        
        userMarkerRef.current = L.marker([latitude, longitude], { icon: userIcon })
          .addTo(mapRef.current);
      }
    };

    const error = (err: GeolocationPositionError) => {
      console.error('GPS Error:', err);
      showToast('Error obteniendo ubicación GPS', 'error');
    };

    watchId = navigator.geolocation.watchPosition(success, error, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 5000
    });

    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, [showToast]);

  // Recenter map to user location
  const recenter = useCallback(() => {
    if (!mapRef.current || !userLocation) return;
    
    mapRef.current.setView([userLocation.lat, userLocation.lng], 16);
    showToast('Centrado en tu ubicación', 'success');
  }, [userLocation, showToast]);

  // Fetch nearby tracks
  const fetchNearbyTracks = useCallback(async () => {
    if (!userLocation) return;

    try {
      const response = await fetch(
        `/api/tracks/near?lat=${userLocation.lat}&lng=${userLocation.lng}&radius_km=100&app_mode=${currentMode}`
      );
      
      if (!response.ok) throw new Error('Failed to fetch nearby tracks');
      
      const data = await response.json();
      
      // Clear existing markers
      if (nearbyMarkersRef.current) {
        nearbyMarkersRef.current.clearLayers();
      }
      
      // Add new markers
      data.items.forEach((track: any) => {
        if (!track.geojson?.coordinates?.[0]) return;
        
        const [lng, lat] = track.geojson.coordinates[0];
        const distanceM = track.distanceKm * 1000;
        
        const marker = L.marker([lat, lng], {
          icon: createTrackIcon(distanceM)
        }).bindPopup(`
          <div class="p-2">
            <h3 class="font-bold">${track.name}</h3>
            <p class="text-sm text-gray-600">${track.distanceKm}km away</p>
            <p class="text-sm">Distance: ${(track.distanceM / 1000).toFixed(1)}km</p>
            <button onclick="selectTrack('${track.id}')" class="mt-2 px-3 py-1 bg-blue-500 text-white rounded text-sm">
              Select Track
            </button>
          </div>
        `);
        
        nearbyMarkersRef.current?.addLayer(marker);
      });
      
      showToast(`Found ${data.items.length} nearby tracks`, 'success');
    } catch (error) {
      console.error('Error fetching nearby tracks:', error);
      showToast('Error loading nearby tracks', 'error');
    }
  }, [userLocation, currentMode, showToast]);

  // Toggle nearby tracks
  useEffect(() => {
    if (nearby.enabled && userLocation) {
      fetchNearbyTracks();
    } else if (nearbyMarkersRef.current) {
      nearbyMarkersRef.current.clearLayers();
    }
  }, [nearby.enabled, fetchNearbyTracks, userLocation]);

  // Start/stop rally
  const toggleRally = useCallback(() => {
    if (!activeTrack) {
      showToast('Select a track first', 'error');
      return;
    }

    if (rallyState.phase === 'idle') {
      setRallyState({
        phase: 'armed',
        startTime: null,
        endTime: null,
        currentAttempt: null
      });
      showToast('Rally armed - approach start line', 'success');
    } else {
      setRallyState({
        phase: 'idle',
        startTime: null,
        endTime: null,
        currentAttempt: null
      });
      showToast('Rally stopped', 'info');
    }
  }, [activeTrack, rallyState.phase, setRallyState, showToast]);

  return (
    <div className="relative w-full h-screen overflow-hidden">
      {/* Map container */}
      <div ref={containerRef} className="absolute inset-0" />
      
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-[1000] bg-white/90 backdrop-blur-sm border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-bold runcycle-gradient bg-clip-text text-transparent">
              RunCycle GPS
            </h1>
            
            {/* Mode selector */}
            <div className="flex rounded-lg overflow-hidden border border-gray-300">
              <button
                onClick={() => setCurrentMode('running')}
                className={`px-4 py-2 text-sm font-medium transition-colors ${
                  currentMode === 'running' 
                    ? 'bg-green-500 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                🏃‍♂️ Running
              </button>
              <button
                onClick={() => setCurrentMode('cycling')}
                className={`px-4 py-2 text-sm font-medium transition-colors ${
                  currentMode === 'cycling' 
                    ? 'bg-blue-500 text-white' 
                    : 'bg-white text-gray-700 hover:bg-gray-50'
                }`}
              >
                🚴‍♂️ Cycling
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Rally control */}
            {activeTrack && (
              <Button
                intent={rallyState.phase === 'idle' ? 'success' : 'danger'}
                size="sm"
                leftIcon={rallyState.phase === 'idle' ? <Play size={16} /> : <Pause size={16} />}
                onClick={toggleRally}
              >
                {rallyState.phase === 'idle' ? 'Start Rally' : 'Stop Rally'}
              </Button>
            )}
            
            <Button
              intent="success"
              size="sm"
              leftIcon={<Route size={16} />}
              onClick={() => showToast('Route creation coming soon!', 'info')}
            >
              Create Route
            </Button>
            
            <Button
              intent="secondary"
              size="sm"
              leftIcon={<Menu size={16} />}
              onClick={() => setMenuOpen(!menuOpen)}
            >
              Menu
            </Button>
          </div>
        </div>
      </div>

      {/* Map controls */}
      <div className="absolute top-20 right-4 z-[1000] flex flex-col gap-2">
        <Button
          intent={canRecenter ? "secondary" : "ghost"}
          size="xs"
          onClick={recenter}
          disabled={!canRecenter}
          title="Center on my location"
          className="w-10 h-10 shadow-lg"
        >
          <Target size={16} />
        </Button>
        
        <Button
          intent="secondary"
          size="xs"
          onClick={() => setSatelliteMode(!satelliteMode)}
          title={satelliteMode ? "Switch to map" : "Switch to satellite"}
          className="w-10 h-10 shadow-lg"
        >
          <Satellite size={16} />
        </Button>
        
        <Button
          intent={nearby.enabled ? "success" : "secondary"}
          size="xs"
          onClick={() => setNearby({ enabled: !nearby.enabled })}
          title="Show nearby tracks (100km)"
          className="w-10 h-10 shadow-lg"
        >
          <Search size={16} />
        </Button>
      </div>

      {/* Status indicator */}
      <div className="absolute bottom-4 left-4 z-[1000] bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2 shadow-lg">
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${
            currentMode === 'running' ? 'bg-green-500' : 'bg-blue-500'
          }`} />
          <span className="text-sm font-medium">
            {currentMode === 'running' ? '🏃‍♂️ RUNNING' : '🚴‍♂️ CYCLING'}
          </span>
          {rallyState.phase !== 'idle' && (
            <span className="text-xs text-gray-600 ml-2">
              Rally: {rallyState.phase.toUpperCase()}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}