import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer } from 'ws';
import multer from 'multer';
import * as turf from '@turf/turf';
import { parseGPX } from 'togeojson/index.js';
import { DOMParser } from '@xmldom/xmldom';
import { db } from "./db.js";
import { tracks, waypoints, attempts, splits } from "@shared/schema";
import { eq, desc, and, sql, asc } from "drizzle-orm";
import { insertTrackSchema, insertAttemptSchema, insertSplitSchema } from "@shared/schema";

const upload = multer({ storage: multer.memoryStorage() });

// WebSocket connections for real-time updates
const wsConnections = new Set<any>();

function broadcastLeaderboardUpdate(trackId: string) {
  const message = JSON.stringify({
    type: 'leaderboard_update',
    trackId: trackId,
    timestamp: Date.now()
  });
  
  wsConnections.forEach(ws => {
    if (ws.readyState === 1) { // WebSocket.OPEN
      ws.send(message);
    }
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", service: "runcycle-gps", timestamp: new Date().toISOString() });
  });

  // Get tracks with optional filtering
  app.get("/api/tracks", async (req, res) => {
    try {
      const { app_mode } = req.query;
      
      let query = db.select().from(tracks);
      
      if (app_mode && (app_mode === 'running' || app_mode === 'cycling')) {
        query = query.where(eq(tracks.appMode, app_mode as 'running' | 'cycling'));
      }
      
      const result = await query.orderBy(desc(tracks.createdAt));
      res.json(result);
    } catch (error) {
      console.error("Error fetching tracks:", error);
      res.status(500).json({ error: "Failed to fetch tracks" });
    }
  });

  // Get nearby tracks
  app.get("/api/tracks/near", async (req, res) => {
    try {
      const { lat, lng, radius_km = 100, app_mode } = req.query;
      
      if (!lat || !lng) {
        return res.status(400).json({ error: "lat and lng parameters required" });
      }

      console.log(`[tracks:near] Searching for tracks near ${lat},${lng} within ${radius_km}km radius for mode ${app_mode}`);

      let query = db.select().from(tracks);
      
      if (app_mode && (app_mode === 'running' || app_mode === 'cycling')) {
        query = query.where(eq(tracks.appMode, app_mode as 'running' | 'cycling'));
      }

      const allTracks = await query;
      
      const userPoint = turf.point([parseFloat(lng as string), parseFloat(lat as string)]);
      const radiusKm = parseFloat(radius_km as string);
      
      const nearbyTracks = allTracks
        .map(track => {
          if (!track.geojson || typeof track.geojson !== 'object') {
            return null;
          }

          try {
            const trackLine = track.geojson as any;
            if (trackLine.type !== 'LineString' || !trackLine.coordinates) {
              return null;
            }

            const firstPoint = turf.point(trackLine.coordinates[0]);
            const distance = turf.distance(userPoint, firstPoint, { units: 'kilometers' });
            
            if (distance <= radiusKm) {
              return { ...track, distanceKm: Math.round(distance * 10) / 10 };
            }
            return null;
          } catch (e) {
            console.error(`Error processing track ${track.id}:`, e);
            return null;
          }
        })
        .filter(Boolean)
        .sort((a, b) => (a?.distanceKm || 0) - (b?.distanceKm || 0));

      console.log(`[tracks:near] Found ${nearbyTracks.length} nearby tracks`);
      res.json({ items: nearbyTracks });
    } catch (error) {
      console.error("Error fetching nearby tracks:", error);
      res.status(500).json({ error: "Failed to fetch nearby tracks" });
    }
  });

  // Upload and create track
  app.post("/api/tracks", upload.single('gpx'), async (req, res) => {
    try {
      let trackData;

      if (req.file) {
        // Handle GPX file upload
        const gpxString = req.file.buffer.toString();
        const xmlDoc = new DOMParser().parseFromString(gpxString, 'text/xml');
        const geojson = parseGPX(xmlDoc);
        
        if (!geojson || !geojson.features || geojson.features.length === 0) {
          return res.status(400).json({ error: "Invalid GPX file" });
        }

        const lineString = geojson.features.find(f => f.geometry.type === 'LineString');
        if (!lineString) {
          return res.status(400).json({ error: "No track found in GPX file" });
        }

        trackData = {
          name: req.body.name || 'Imported Track',
          geojson: lineString.geometry,
          appMode: req.body.app_mode || 'running',
          waypointEveryM: req.body.app_mode === 'running' ? 100 : 1000
        };
      } else {
        // Handle JSON data from route builder
        const validatedData = insertTrackSchema.parse(req.body);
        trackData = validatedData;
      }

      // Calculate track metrics
      const geom = trackData.geojson as any;
      const distance = turf.length(geom, { units: 'meters' });
      
      // Create track record
      const [newTrack] = await db.insert(tracks).values({
        ...trackData,
        distanceM: distance,
      }).returning();

      // Generate waypoints
      const waypointSpacing = trackData.waypointEveryM || (trackData.appMode === 'running' ? 100 : 1000);
      const waypointData = [];
      
      for (let distanceM = 0; distanceM <= distance; distanceM += waypointSpacing) {
        const point = turf.along(geom, distanceM / 1000, { units: 'kilometers' });
        waypointData.push({
          trackId: newTrack.id,
          waypointNumber: Math.floor(distanceM / waypointSpacing) + 1,
          distanceFromStartM: distanceM,
          lat: point.geometry.coordinates[1],
          lng: point.geometry.coordinates[0],
        });
      }

      if (waypointData.length > 0) {
        await db.insert(waypoints).values(waypointData);
      }

      res.json(newTrack);
    } catch (error) {
      console.error("Error creating track:", error);
      res.status(500).json({ error: "Failed to create track" });
    }
  });

  // Delete track
  app.delete("/api/tracks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Delete track (cascades to waypoints, attempts, and splits)
      await db.delete(tracks).where(eq(tracks.id, id));
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting track:", error);
      res.status(500).json({ error: "Failed to delete track" });
    }
  });

  // Get track with waypoints
  app.get("/api/tracks/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const [track] = await db.select().from(tracks).where(eq(tracks.id, id));
      if (!track) {
        return res.status(404).json({ error: "Track not found" });
      }

      const trackWaypoints = await db.select()
        .from(waypoints)
        .where(eq(waypoints.trackId, id))
        .orderBy(asc(waypoints.waypointNumber));

      res.json({ ...track, waypoints: trackWaypoints });
    } catch (error) {
      console.error("Error fetching track:", error);
      res.status(500).json({ error: "Failed to fetch track" });
    }
  });

  // Start attempt
  app.post("/api/attempts", async (req, res) => {
    try {
      const validatedData = insertAttemptSchema.parse(req.body);
      
      const [newAttempt] = await db.insert(attempts).values({
        ...validatedData,
        startTime: new Date(),
        status: 'running'
      }).returning();

      res.json(newAttempt);
    } catch (error) {
      console.error("Error creating attempt:", error);
      res.status(500).json({ error: "Failed to create attempt" });
    }
  });

  // Finish attempt
  app.patch("/api/attempts/:id/finish", async (req, res) => {
    try {
      const { id } = req.params;
      const { totalTimeMs, maxSpeedKmh, avgSpeedKmh, distanceCoveredM } = req.body;

      const [updatedAttempt] = await db.update(attempts)
        .set({
          endTime: new Date(),
          totalTimeMs,
          maxSpeedKmh,
          avgSpeedKmh,
          distanceCoveredM,
          status: 'finished'
        })
        .where(eq(attempts.id, id))
        .returning();

      if (updatedAttempt) {
        // Calculate score and percentile
        const trackAttempts = await db.select()
          .from(attempts)
          .where(and(
            eq(attempts.trackId, updatedAttempt.trackId),
            eq(attempts.status, 'finished')
          ))
          .orderBy(asc(attempts.totalTimeMs));

        const totalAttempts = trackAttempts.length;
        const position = trackAttempts.findIndex(a => a.id === id) + 1;
        const percentile = ((totalAttempts - position + 1) / totalAttempts) * 100;
        const score = Math.round(percentile * 10); // Score out of 1000

        await db.update(attempts)
          .set({ score, percentile })
          .where(eq(attempts.id, id));

        // Broadcast leaderboard update
        broadcastLeaderboardUpdate(updatedAttempt.trackId);
      }

      res.json(updatedAttempt);
    } catch (error) {
      console.error("Error finishing attempt:", error);
      res.status(500).json({ error: "Failed to finish attempt" });
    }
  });

  // Add split
  app.post("/api/splits", async (req, res) => {
    try {
      const validatedData = insertSplitSchema.parse(req.body);
      
      const [newSplit] = await db.insert(splits).values(validatedData).returning();
      res.json(newSplit);
    } catch (error) {
      console.error("Error creating split:", error);
      res.status(500).json({ error: "Failed to create split" });
    }
  });

  // Get leaderboard for track
  app.get("/api/tracks/:id/leaderboard", async (req, res) => {
    try {
      const { id } = req.params;
      
      const leaderboard = await db.select({
        id: attempts.id,
        displayName: attempts.displayName,
        totalTimeMs: attempts.totalTimeMs,
        maxSpeedKmh: attempts.maxSpeedKmh,
        avgSpeedKmh: attempts.avgSpeedKmh,
        score: attempts.score,
        percentile: attempts.percentile,
        createdAt: attempts.createdAt
      })
      .from(attempts)
      .where(and(
        eq(attempts.trackId, id),
        eq(attempts.status, 'finished')
      ))
      .orderBy(desc(attempts.score));

      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ error: "Failed to fetch leaderboard" });
    }
  });

  // Route generation with OpenRouteService
  app.post("/api/routes", async (req, res) => {
    try {
      const { waypoints, profile = 'foot-hiking', alternatives = 1 } = req.body;
      
      if (!waypoints || waypoints.length < 2) {
        return res.status(400).json({ error: "At least 2 waypoints required" });
      }

      const orsApiKey = process.env.ORS_API_KEY;
      if (!orsApiKey) {
        return res.status(500).json({ error: "ORS API key not configured" });
      }

      const orsProfile = profile === 'running' ? 'foot-hiking' : 'cycling-mountain';
      
      const orsResponse = await fetch('https://api.openrouteservice.org/v2/directions/' + orsProfile + '/geojson', {
        method: 'POST',
        headers: {
          'Authorization': orsApiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          coordinates: waypoints,
          alternative_routes: { target_count: alternatives },
          elevation: true,
          extra_info: ['surface', 'steepness'],
          instructions: false
        })
      });

      if (!orsResponse.ok) {
        const errorText = await orsResponse.text();
        console.error('[ORS] Error:', orsResponse.status, errorText);
        return res.status(502).json({ error: `Route service error: ${orsResponse.status}` });
      }

      const routeData = await orsResponse.json();
      
      if (!routeData.features || routeData.features.length === 0) {
        return res.status(404).json({ error: "No route found" });
      }

      const route = routeData.features[0];
      const summary = route.properties.summary;
      
      // Calculate surface breakdown
      const surfaceData = route.properties.extras?.surface || [];
      let onroadM = 0, offroadM = 0;
      
      surfaceData.forEach((segment: any) => {
        const [startIdx, endIdx, surfaceType] = segment;
        const segmentCoords = route.geometry.coordinates.slice(startIdx, endIdx + 1);
        const segmentDistance = turf.length(turf.lineString(segmentCoords), { units: 'meters' });
        
        // Surface types: 1=paved, 2=unpaved, 3=asphalt, etc.
        if ([1, 3, 4].includes(surfaceType)) {
          onroadM += segmentDistance;
        } else {
          offroadM += segmentDistance;
        }
      });

      res.json({
        geometry: route.geometry,
        distanceM: summary.distance,
        elevationGain: Math.round(summary.ascent || 0),
        estimatedTimeMin: Math.round(summary.duration / 60),
        onroadKm: Math.round(onroadM / 100) / 10,
        offroadKm: Math.round(offroadM / 100) / 10,
        difficulty: summary.distance > 10000 ? 'hard' : summary.distance > 5000 ? 'moderate' : 'easy',
        surfaceData: surfaceData
      });
    } catch (error) {
      console.error("Error generating route:", error);
      res.status(500).json({ error: "Failed to generate route" });
    }
  });

  // Create HTTP server and WebSocket server
  const httpServer = createServer(app);
  
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws' 
  });

  wss.on('connection', (ws) => {
    console.log('📡 WebSocket client connected');
    wsConnections.add(ws);

    ws.on('close', () => {
      console.log('📡 WebSocket client disconnected');
      wsConnections.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('📡 WebSocket error:', error);
      wsConnections.delete(ws);
    });
  });

  return httpServer;
}