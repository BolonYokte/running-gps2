import { sql } from 'drizzle-orm';
import {
  index,
  integer,
  pgTable,
  real,
  text,
  timestamp,
  varchar,
  boolean,
  jsonb,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  displayName: varchar("display_name"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tracks table - stores GPS routes for running and cycling
export const tracks = pgTable("tracks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  geojson: jsonb("geojson").notNull(),
  distanceM: real("distance_m"),
  elevationGain: real("elevation_gain"),
  difficulty: varchar("difficulty", { enum: ['easy', 'moderate', 'hard', 'extreme'] }),
  appMode: varchar("app_mode", { enum: ['running', 'cycling'] }).notNull(),
  waypointEveryM: integer("waypoint_every_m").default(1000),
  onroadKm: real("onroad_km"),
  offroadKm: real("offroad_km"),
  estimatedTimeMin: integer("estimated_time_min"),
  surfaceData: jsonb("surface_data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Waypoints table - split points along tracks
export const waypoints = pgTable("waypoints", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackId: varchar("track_id").notNull().references(() => tracks.id, { onDelete: 'cascade' }),
  waypointNumber: integer("waypoint_number").notNull(),
  distanceFromStartM: real("distance_from_start_m").notNull(),
  lat: real("lat").notNull(),
  lng: real("lng").notNull(),
  elevation: real("elevation"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Attempts table - rally sessions/runs
export const attempts = pgTable("attempts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  trackId: varchar("track_id").notNull().references(() => tracks.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").references(() => users.id),
  displayName: varchar("display_name"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  totalTimeMs: integer("total_time_ms"),
  maxSpeedKmh: real("max_speed_kmh"),
  avgSpeedKmh: real("avg_speed_kmh"),
  distanceCoveredM: real("distance_covered_m"),
  status: varchar("status", { enum: ['running', 'finished', 'abandoned'] }).default('running'),
  appMode: varchar("app_mode", { enum: ['running', 'cycling'] }).notNull(),
  score: integer("score"),
  percentile: real("percentile"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Splits table - waypoint times during attempts
export const splits = pgTable("splits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  attemptId: varchar("attempt_id").notNull().references(() => attempts.id, { onDelete: 'cascade' }),
  waypointId: varchar("waypoint_id").notNull().references(() => waypoints.id, { onDelete: 'cascade' }),
  waypointNumber: integer("waypoint_number").notNull(),
  timeFromStartMs: integer("time_from_start_ms").notNull(),
  distanceFromStartM: real("distance_from_start_m").notNull(),
  speedKmh: real("speed_kmh"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Type exports
export type User = typeof users.$inferSelect;
export type UpsertUser = typeof users.$inferInsert;
export type Track = typeof tracks.$inferSelect;
export type InsertTrack = typeof tracks.$inferInsert;
export type Waypoint = typeof waypoints.$inferSelect;
export type InsertWaypoint = typeof waypoints.$inferInsert;
export type Attempt = typeof attempts.$inferSelect;
export type InsertAttempt = typeof attempts.$inferInsert;
export type Split = typeof splits.$inferSelect;
export type InsertSplit = typeof splits.$inferInsert;

// Zod schemas for validation
export const insertTrackSchema = createInsertSchema(tracks).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertAttemptSchema = createInsertSchema(attempts).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertSplitSchema = createInsertSchema(splits).omit({ 
  id: true, 
  createdAt: true 
});

export const insertWaypointSchema = createInsertSchema(waypoints).omit({ 
  id: true, 
  createdAt: true 
});

export type InsertTrackType = z.infer<typeof insertTrackSchema>;
export type InsertAttemptType = z.infer<typeof insertAttemptSchema>;
export type InsertSplitType = z.infer<typeof insertSplitSchema>;
export type InsertWaypointType = z.infer<typeof insertWaypointSchema>;